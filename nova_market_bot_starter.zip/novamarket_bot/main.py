import os
import asyncio
import logging
import sqlite3
from pathlib import Path
from aiogram import Bot, Dispatcher, F
from aiogram.filters import CommandStart, Command
from aiogram.types import (
    Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton,
    LabeledPrice, PreCheckoutQuery
)
from aiogram.utils.keyboard import InlineKeyboardBuilder
from dotenv import load_dotenv

load_dotenv()
BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
ADMIN_ID = int(os.getenv("ADMIN_ID", "0"))
DB_PATH = os.getenv("DB_PATH", "data/shop.db")
SHOP_NAME = os.getenv("SHOP_NAME", "NOVA MARKET")
SUPPORT_USERNAME = os.getenv("SUPPORT_USERNAME", "").lstrip("@")
RUB_PAYMENT_INFO = os.getenv("RUB_PAYMENT_INFO", "Оплата в рублях пока настраивается. Напишите администратору.")
CRYPTO_PAYMENT_INFO = os.getenv("CRYPTO_PAYMENT_INFO", "Криптооплата пока настраивается. Напишите администратору.")

if not BOT_TOKEN:
    raise RuntimeError("Укажи BOT_TOKEN в файле .env")

Path(DB_PATH).parent.mkdir(parents=True, exist_ok=True)
logging.basicConfig(level=logging.INFO)

def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    with db() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            category TEXT NOT NULL,
            title TEXT NOT NULL,
            description TEXT NOT NULL,
            price_rub INTEGER NOT NULL,
            stock TEXT NOT NULL DEFAULT 'В наличии',
            active INTEGER NOT NULL DEFAULT 1
        )""")
        con.execute("""CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            payment_method TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'Ожидает оплаты',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )""")

CATEGORIES = {
    "accounts": "👤 Аккаунты",
    "gifts": "🎁 Подарки",
    "stars": "⭐ Telegram Stars",
    "nft": "💎 NFT",
}

def kb_main():
    b = InlineKeyboardBuilder()
    b.button(text="🛍 Каталог", callback_data="catalog")
    b.button(text="📦 Мои заказы", callback_data="myorders")
    b.button(text="🆘 Поддержка", callback_data="support")
    b.adjust(1)
    return b.as_markup()

def kb_categories():
    b = InlineKeyboardBuilder()
    for key, label in CATEGORIES.items():
        b.button(text=label, callback_data=f"cat:{key}")
    b.button(text="⬅️ Главное меню", callback_data="home")
    b.adjust(2, 2, 1)
    return b.as_markup()

def kb_back():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⬅️ В каталог", callback_data="catalog")]
    ])

async def show_catalog(target):
    await target.answer("Выбери категорию:", reply_markup=kb_categories())

async def start_handler(message: Message):
    await message.answer(
        f"✨ Добро пожаловать в <b>{SHOP_NAME}</b>!\n\n"
        "Здесь можно приобрести аккаунты, подарки, Telegram Stars и NFT.\n"
        "Выбери нужный раздел:",
        reply_markup=kb_main(), parse_mode="HTML"
    )

async def catalog_handler(c: CallbackQuery):
    await c.message.edit_text("🛍 <b>Каталог</b>\nВыбери категорию:", reply_markup=kb_categories(), parse_mode="HTML")
    await c.answer()

async def category_handler(c: CallbackQuery):
    key = c.data.split(":", 1)[1]
    if key not in CATEGORIES:
        await c.answer("Категория не найдена", show_alert=True); return
    with db() as con:
        rows = con.execute("SELECT * FROM products WHERE category=? AND active=1 ORDER BY id DESC", (key,)).fetchall()
    b = InlineKeyboardBuilder()
    for p in rows:
        b.button(text=f"{p['title']} — {p['price_rub']} ₽", callback_data=f"product:{p['id']}")
    b.button(text="⬅️ Назад", callback_data="catalog")
    b.adjust(1)
    text = f"<b>{CATEGORIES[key]}</b>\n\n"
    text += "\n".join([f"• {p['title']} — {p['price_rub']} ₽" for p in rows]) if rows else "Пока товаров нет. Загляни позже!"
    await c.message.edit_text(text, reply_markup=b.as_markup(), parse_mode="HTML")
    await c.answer()

async def product_handler(c: CallbackQuery):
    pid = int(c.data.split(":")[1])
    with db() as con:
        p = con.execute("SELECT * FROM products WHERE id=? AND active=1", (pid,)).fetchone()
    if not p:
        await c.answer("Товар уже недоступен", show_alert=True); return
    b = InlineKeyboardBuilder()
    b.button(text="🛒 Купить", callback_data=f"buy:{pid}")
    b.button(text="⬅️ К товарам", callback_data=f"cat:{p['category']}")
    b.adjust(1)
    await c.message.edit_text(
        f"<b>{p['title']}</b>\n\n{p['description']}\n\n"
        f"💰 Цена: <b>{p['price_rub']} ₽</b>\n📦 {p['stock']}",
        reply_markup=b.as_markup(), parse_mode="HTML"
    )
    await c.answer()

async def buy_handler(c: CallbackQuery):
    pid = int(c.data.split(":")[1])
    with db() as con:
        p = con.execute("SELECT * FROM products WHERE id=? AND active=1", (pid,)).fetchone()
    if not p:
        await c.answer("Товар недоступен", show_alert=True); return
    b = InlineKeyboardBuilder()
    # Digital goods in Telegram bots should use Telegram Stars (XTR).
    b.button(text="⭐ Оплатить Telegram Stars", callback_data=f"payxtr:{pid}")
    b.button(text="₽ Оплата в рублях", callback_data=f"payrub:{pid}")
    b.button(text="₿ Криптооплата", callback_data=f"paycrypto:{pid}")
    b.button(text="⬅️ Назад", callback_data=f"product:{pid}")
    b.adjust(1)
    await c.message.edit_text(
        f"Покупка: <b>{p['title']}</b>\nЦена: {p['price_rub']} ₽\n\nВыбери способ оплаты.",
        reply_markup=b.as_markup(), parse_mode="HTML"
    )
    await c.answer()

async def pay_xtr(c: CallbackQuery, bot: Bot):
    pid = int(c.data.split(":")[1])
    with db() as con:
        p = con.execute("SELECT * FROM products WHERE id=? AND active=1", (pid,)).fetchone()
    if not p:
        await c.answer("Товар недоступен", show_alert=True); return
    # Configure a Stars price in Telegram Stars before enabling this option.
    await c.answer("Оплата Stars будет включена после настройки цены в ⭐. Пока напиши администратору.", show_alert=True)
    if ADMIN_ID:
        await bot.send_message(ADMIN_ID, f"Пользователь {c.from_user.id} хочет купить товар #{pid} ({p['title']}). Нужно настроить цену в Telegram Stars.")

async def external_payment(c: CallbackQuery, bot: Bot):
    kind, pid_s = c.data.split(":")
    pid = int(pid_s)
    with db() as con:
        p = con.execute("SELECT * FROM products WHERE id=? AND active=1", (pid,)).fetchone()
        if not p:
            await c.answer("Товар недоступен", show_alert=True); return
        cur = con.execute(
            "INSERT INTO orders(user_id, product_id, payment_method, status) VALUES(?,?,?,?)",
            (c.from_user.id, pid, kind, "Ожидает подтверждения оплаты")
        )
        order_id = cur.lastrowid
    info = RUB_PAYMENT_INFO if kind == "payrub" else CRYPTO_PAYMENT_INFO
    await c.message.edit_text(
        f"🧾 Заказ <b>#{order_id}</b>\nТовар: {p['title']}\nСумма: {p['price_rub']} ₽\n\n"
        f"{info}\n\nПосле оплаты отправь чек/скриншот сюда. Заказ проверит администратор.",
        parse_mode="HTML", reply_markup=kb_main()
    )
    await c.answer()
    if ADMIN_ID:
        await bot.send_message(ADMIN_ID, f"Новый заказ #{order_id}\nТовар: {p['title']}\nСпособ: {kind}\nПокупатель: {c.from_user.id}")

async def proof_handler(message: Message, bot: Bot):
    if not ADMIN_ID:
        return
    if message.photo:
        await bot.send_photo(ADMIN_ID, message.photo[-1].file_id,
            caption=f"Чек от пользователя {message.from_user.id}\nПодпись: {message.caption or 'нет'}")
    elif message.text and not message.text.startswith("/"):
        await bot.send_message(ADMIN_ID, f"Сообщение/чек от пользователя {message.from_user.id}:\n{message.text}")

async def myorders_handler(c: CallbackQuery):
    with db() as con:
        rows = con.execute("""SELECT o.id, o.status, p.title FROM orders o
            JOIN products p ON p.id=o.product_id WHERE o.user_id=? ORDER BY o.id DESC LIMIT 10""",
            (c.from_user.id,)).fetchall()
    text = "📦 <b>Мои заказы</b>\n\n" + ("\n".join([f"#{r['id']} — {r['title']} — {r['status']}" for r in rows]) if rows else "Заказов пока нет.")
    await c.message.edit_text(text, reply_markup=kb_main(), parse_mode="HTML")
    await c.answer()

async def support_handler(c: CallbackQuery):
    text = "🆘 По вопросам заказа напиши администратору."
    if SUPPORT_USERNAME:
        text += f"\nКонтакт: @{SUPPORT_USERNAME}"
    await c.message.edit_text(text, reply_markup=kb_main())
    await c.answer()

async def home_handler(c: CallbackQuery):
    await c.message.edit_text(f"✨ <b>{SHOP_NAME}</b>\nВыбери действие:", reply_markup=kb_main(), parse_mode="HTML")
    await c.answer()

async def add_handler(message: Message):
    if message.from_user.id != ADMIN_ID:
        return
    # Format: /add category|title|description|price_rub|stock
    raw = message.text.partition(" ")[2]
    parts = raw.split("|")
    if len(parts) != 5 or parts[0] not in CATEGORIES:
        await message.answer("Формат:\n/add accounts|Название|Описание|Цена_в_рублях|В наличии")
        return
    category, title, description, price, stock = [x.strip() for x in parts]
    try:
        price = int(price)
        if price <= 0: raise ValueError()
    except ValueError:
        await message.answer("Цена должна быть целым числом больше нуля."); return
    with db() as con:
        cur = con.execute("INSERT INTO products(category,title,description,price_rub,stock) VALUES(?,?,?,?,?)",
                          (category,title,description,price,stock))
        pid = cur.lastrowid
    await message.answer(f"✅ Товар добавлен. ID: {pid}")

async def admin_handler(message: Message):
    if message.from_user.id != ADMIN_ID:
        await message.answer("Эта команда доступна только администратору."); return
    await message.answer(
        "🔐 <b>Админ-панель</b>\n\n"
        "Добавить товар:\n"
        "<code>/add accounts|Название|Описание|Цена|В наличии</code>\n\n"
        "Категории: accounts, gifts, stars, nft\n"
        "Заказы и чеки приходят сюда.",
        parse_mode="HTML"
    )

async def main():
    init_db()
    bot = Bot(BOT_TOKEN)
    dp = Dispatcher()
    dp.message.register(start_handler, CommandStart())
    dp.message.register(admin_handler, Command("admin"))
    dp.message.register(add_handler, Command("add"))
    dp.message.register(proof_handler)
    dp.callback_query.register(catalog_handler, F.data == "catalog")
    dp.callback_query.register(myorders_handler, F.data == "myorders")
    dp.callback_query.register(support_handler, F.data == "support")
    dp.callback_query.register(home_handler, F.data == "home")
    dp.callback_query.register(category_handler, F.data.startswith("cat:"))
    dp.callback_query.register(product_handler, F.data.startswith("product:"))
    dp.callback_query.register(buy_handler, F.data.startswith("buy:"))
    dp.callback_query.register(pay_xtr, F.data.startswith("payxtr:"))
    dp.callback_query.register(external_payment, F.data.startswith("payrub:") | F.data.startswith("paycrypto:"))
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
